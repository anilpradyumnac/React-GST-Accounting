import React,{Component} from 'react';
import firebase from './../../../stub/FirebaseConfig';
import Button from 'material-ui/RaisedButton';
import Modal from 'react-responsive-modal';
import If from './../../utils/components/If.js';
import TextField from 'material-ui/TextField';
import RandomSelector from './Random';
import QtySelector from './QtySelector';

const isOnline = require('is-online'); 

class BillMain extends Component{
	constructor(props) {
	  super(props);
	  this.state = {KeyBoardShowing:false,ExchangeChecked:false,modalDatax:[],ShowOtherModal:false ,invUnderOperation:'',PartyName:'Cash',PartyAddr:'',PartyGSTIN:'',billSettingModal:false,SpecialQTY:0,SpecialQTYPrice:0,SpecialQTYPricex:0,ChangingFunc:()=>{},QtySelModal:false,data:[],dataKey:[],modalVisible:false,modalData:[],cart:[],cartModalVisible:false};
	}
	componentWillMount(){
    	var self = this;
    	isOnline().then(online => {
    			if(!online){
    			
    				var arr1 = JSON.parse(localStorage.getItem('ShowPageKeys'));

    				var arr = JSON.parse(localStorage.getItem('ShowPageData'));
    				alert('It Seems Like You dont have a working Internet Connection!! Launching in Offline Mode');
    				this.setState({data:arr,dataKey:arr1,showText:`No Internet Connection: Loading Old ${arr1.length} Items(s)...... `});
    			}
    			else{
	   				firebase.database().ref('items').on('value', (snapshot) => {
				 		console.log(snapshot.val());
				 		var arr = [];
				 		var arr1 =[];
				 		for(var key in snapshot.val())
						{
							let i = key;
							arr1.push(i);
	    					arr.push(snapshot.val()[key].data);
						}
						self.setState({data:arr,dataKey:arr1});
	   			  	 });
	   			}
			});
		}
	_showOtherModal(){
  		this.setState({ShowOtherModal:true});
  	}
  	 _hideModal(){
  	this.setState({ modalVisible: false,modalData:[] });
 	 }
  	_closeOtherModal(){
  		this.setState({ShowOtherModal:false});
  	}
  	RandomSelectorHandler(item){
  		 
  		if(this.state.data.length>0 && item!=-1){
  			let ArrayOfData = this.state.data;
  			var arr = [];
  			ArrayOfData.map((datax)=>{
				if(datax.checked && datax.ItemCategory==item){
					arr.push(datax);
				}
  			});
  			console.log('Selected Random');
  			console.log(arr[0]);
  			this.setState({modalDatax:arr[0],modalData:arr[0],RandomSelectorShow:false });
		}
  	}
  	hideQtySelector(){
  		this.setState({QtySelModal:false});
  	}
  	specialQtyChangeHandler(supplied){
    	this.setState({SpecialQTY:supplied});
  	}
  	AddToCartClicked(special){
      if(special){
       
        var OpenedModalItem = this.state.modalData;
        let {ItemCategory,CGST,IGST,MaxSize,MinSize,SGST, SizeStep,checked,Discount} = this.state.modalData;
        var SizePrices = {};
        console.log(OpenedModalItem);
        SizePrices['SpecialQTYPrice'] = this.state.SpecialQTYPrice;
        var ObjectToPush = {};
        var SelectedSizesArray = [];
        ObjectToPush['ItemCategory'] = ItemCategory;
        ObjectToPush['CGST'] = CGST;
        ObjectToPush['IGST'] = IGST;
        ObjectToPush['SGST'] = SGST;
        ObjectToPush['checked'] = checked;
        ObjectToPush['SizePrices'] = SizePrices;
        ObjectToPush['Discount'] = Discount;
        var CartOld = this.state.cart;
        var toPush = {};
        var qty = this.state.SpecialQTY;
        var sizex = ItemCategory;
        var SelectedSizesArray = [];
        var flag = false;
        var cartIndex = -1;
        toPush['Size'] =  sizex;
        toPush['Qty'] = qty;
        if(qty>0){
          SelectedSizesArray.push(toPush);
        }
        ObjectToPush['SelectedSizesArray'] = SelectedSizesArray;
       
        for(item in CartOld ){
          if(CartOld[item].ItemCategory==OpenedModalItem.ItemCategory){
            flag = true;
            cartIndex = item; 
          }
        }

        if(flag && this.state.modalDatax.length==0){
         if(SelectedSizesArray.length==0){
          CartOld.splice(cartIndex,1);
        }else{
          CartOld[cartIndex] = ObjectToPush;
        }
      }   
      else{
      	
        CartOld.push(ObjectToPush)
      }
      console.log('Finally Cart is:');
      console.log(CartOld);
      
      this.setState({cart:CartOld, modalVisible: false,modalDatax:{},RandomSelectorShow:false,SpecialQTY:0,SpecialQTYPrice:0,ShowOtherModal:false });

      }
      else{
      var QuantitiesSelected = this.state.Quantities;
      var CartOld = this.state.cart;
      var flag = false;
      var cartIndex = 0;
      var OpenedModalItem = this.state.modalData;
      let {ItemCategory,CGST,IGST,MaxSize,MinSize,SGST, SizeStep,checked,SizePrices} = this.state.modalData;
      
      var ObjectToPush = {};
      var SelectedSizesArray = [];
      var i ;
      var self = this;
      console.log('Initial;y Cart is:');
      console.log(CartOld);
      ObjectToPush['ItemCategory'] = ItemCategory;
      ObjectToPush['CGST'] = CGST;
      ObjectToPush['IGST'] = IGST;
      ObjectToPush['MaxSize'] = MaxSize;
      ObjectToPush['MinSize'] = MinSize;
      ObjectToPush['SGST'] = SGST;
      ObjectToPush['SizeStep'] = SizeStep;
      ObjectToPush['checked'] = checked;
      ObjectToPush['SizePrices'] = SizePrices;
      for(i=parseInt(MinSize);i<=parseInt(MaxSize);i+=parseInt(SizeStep)){
        let k = i;
        let selectedToSeek = 'Qty'+k;
        if(parseInt(self.state.Quantities[selectedToSeek]) > 0){
          var toPush = {};
          var qty = self.state.Quantities[selectedToSeek];
          var Sizex = k;
          toPush['Size'] =  Sizex;
          toPush['Qty'] = qty;
          SelectedSizesArray.push(toPush);
        }
      }
      ObjectToPush['SelectedSizesArray'] = SelectedSizesArray;

      for(var item in CartOld ){
        console.log(item);
        if(CartOld[item].ItemCategory==OpenedModalItem.ItemCategory){
          flag = true;
          cartIndex = item; 
        }
      }
      if(flag){
        if(SelectedSizesArray.length==0){
          CartOld.splice(cartIndex,1);
        }else{
          CartOld[cartIndex] = ObjectToPush;
        }
      }   
      else{
        CartOld.push(ObjectToPush)
      } 
      console.log('Finally Cart is:');
      console.log(CartOld);
      
      this.setState({cart:CartOld, modalVisible: false});

      }
  	}
  	renderTotalItems(){
  		var cartNow = this.state.cart;
  		var count = 0;
  		for(var products in cartNow){
  			for(var qts in cartNow[products].SelectedSizesArray ){
   				count = count + parseInt(cartNow[products].SelectedSizesArray[qts].Qty);
  			}
  		}
  		return(count)
  	}
  	 _showCartModal(){
  	var cart = this.state.cart;
  	if(cart.length>0){
  		this.setState({ cartModalVisible: true});
  	}
  	else{
  		alert('No Item(s) to Bill, Please Select at least one Item and Try Again');
  	}
  }
   _hideCartModal(){
  	this.setState({ cartModalVisible: false});
  }
  _showModal(ModalItem){
    console.log('SHowModal Called');
  	var i =0;
  	var Quantities = {};
  	var PresentCart = this.state.cart;
  	var flag = false;
  	var Index = 0;
  	for(var item in PresentCart ){
  		if(PresentCart[item].ItemCategory==ModalItem.ItemCategory){
  			flag = true;
  			Index = item;

  		}
  	}

  	if(flag===false){
      console.log('Item Not in cart');
      if(ModalItem.checked){
        this.setState({ modalVisible: true,modalData:ModalItem,SpecialQTY:0,SpecialQTYPrice:0 });
      }
      else{
        for(i=parseInt(ModalItem.MinSize);i<=parseInt(ModalItem.MaxSize);i+=parseInt(ModalItem.SizeStep)){
        let k = i;
        var key = 'Qty'+k;
        Quantities[key] = '0';  
        }
        Quantities['Odd']='0';
  		  this.setState({ modalVisible: true,modalData:ModalItem,Quantities:Quantities });
        
		  } 	
	
  	}
  	else{
      console.log('Item in Cart');
      if(ModalItem.checked){
        var spQT = PresentCart[item].SelectedSizesArray[0].Qty; 
        console.log(PresentCart[item]);
        var spPrice =  PresentCart[item].SizePrices['SpecialQTYPrice'];  
        console.log('Price: '+spQT);
        this.setState({ modalVisible: true,modalData:ModalItem,SpecialQTY:spQT,SpecialQTYPrice:spPrice }); 
      }
      else{
        for(i=parseInt(ModalItem.MinSize);i<=parseInt(ModalItem.MaxSize);i+=parseInt(ModalItem.SizeStep)){
      let k = i;
      let internalFlag = false;
      let InternalIndex = 0;
      for(var values in PresentCart[Index].SelectedSizesArray ){
        if(k==parseInt(PresentCart[Index].SelectedSizesArray[values].Size)){
          internalFlag = true;
          InternalIndex = values;
        }
      }
      var key = 'Qty'+k;
      if(internalFlag){
        Quantities[key] = PresentCart[Index].SelectedSizesArray[InternalIndex].Qty;
      }
      else{
        Quantities[key] = '0';
      }
      
      
    }
    this.setState({ modalVisible: true,modalData:ModalItem,Quantities:Quantities });
      }
  		 
  	}
  	
  	
  } 
  renderNotSpecial(){
  		var MainArr = [];
		var i,j;
		var self = this;


		for(i=parseInt(this.state.modalData.MinSize);i<=parseInt(this.state.modalData.MaxSize);i+=parseInt(this.state.modalData.SizeStep)){
	 		let k = i;
	 		let keyToSeek = 'size'+k;
	 		let selectedToSeek = 'Qty'+k;
	 		let selectedValue=self.state.Quantities[selectedToSeek]; 	
	 		let ChangeHandler = (q)=>{
	 			let Obj = self.state.Quantities;
	 			Obj[selectedToSeek]=q.toString();
	 			self.setState({Quantities:Obj});
	 		}
	

   			MainArr.push(
   				<div style={{width:'100%',display:'flex',flexDirection: 'row',justifyContent: 'space-around' ,alignItems: 'center'  }}>
	            			 		<h2 style={{color: '#3F51B5',textAlign:'center', flex:1, fontSize: 18,justifyContent: 'center',alignItems:  'center'  }}>{k}</h2>
	            			 		<h2 style={{color: '#3F51B5',textAlign:'center',flex:1, fontSize: 18,justifyContent: 'center',alignItems:  'center'  }}>{this.state.modalData.SizePrices[keyToSeek]}</h2>
	            			 		<Button label={selectedValue} labelColor='#FFC107' labelStyle={{fontSize:18}} backgroundColor='#3F51B5' style={{flex:1,alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:30,marginLeft: '2%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}}   onClick={()=>{self.setState({QtySelModal:true,ChangingFunc:ChangeHandler})}}>
									</Button>
				</div>					
	            			 		 
	  		);
 		}
     		return(MainArr);
  	}
  	renderMemo(){
  		var cartNow = this.state.cart;
  		var RenderingArr = [];
  		for(var products in cartNow){
        if(cartNow[products].checked){
           RenderingArr.push(
           	  <div key={'Memo+Special'+products} style={{width:'100%',display:'flex',flexDirection: 'row',justifyContent: 'space-around' ,alignItems: 'center'  }}>
	          	<h2 key={'MemoText1special+'+products} style={{color: '#3F51B5',textAlign:'center', flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}>{cartNow[products].ItemCategory}</h2>
	            <h2 key={'MemoText2special+'+products} style={{color: '#3F51B5',textAlign:'center',flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}>{cartNow[products].SelectedSizesArray[0].Qty}</h2>
	            <h2 key={'MemoText3special+'+products} style={{color: '#3F51B5', textAlign:'center',flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}>{cartNow[products].SizePrices['SpecialQTYPrice'] * cartNow[products].SelectedSizesArray[0].Qty}/-</h2>
	            <h2 key={'MemoText4special+'+products} style={{color: '#3F51B5', textAlign:'center',flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}> {parseFloat((cartNow[products].SizePrices['SpecialQTYPrice'] * cartNow[products].SelectedSizesArray[0].Qty) +(cartNow[products].SizePrices['SpecialQTYPrice'] * cartNow[products].SelectedSizesArray[0].Qty * cartNow[products].SGST/100)+(cartNow[products].SizePrices['SpecialQTYPrice'] * cartNow[products].SelectedSizesArray[0].Qty * cartNow[products].CGST/100)).toFixed(2)}/-</h2>
	            		
	          </div>

            )
        }
        else{
          for(var qts in cartNow[products].SelectedSizesArray ){
          let key = 'size'+ cartNow[products].SelectedSizesArray[qts].Size;
          RenderingArr.push(
                  	<div key={'MemoTexxxxxt1+'+qts+products}  style={{width:'100%',display:'flex',flexDirection: 'row',justifyContent: 'space-around' ,alignItems: 'center'  }}>
	            		<h2 key={'MemoText1+'+qts+products} style={{color: '#3F51B5',textAlign:'center', flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}>{cartNow[products].ItemCategory}-{cartNow[products].SelectedSizesArray[qts].Size}</h2>
	            		<h2 key={'MemoText2+'+qts+products} style={{color: '#3F51B5',textAlign:'center',flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}>{cartNow[products].SelectedSizesArray[qts].Qty}</h2>
	            		<h2 key={'MemoText3+'+qts+products} style={{color: '#3F51B5', textAlign:'center',flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}>{cartNow[products].SizePrices[key] * cartNow[products].SelectedSizesArray[qts].Qty}/-</h2>
	            		<h2 key={'MemoText4+'+qts+products} style={{color: '#3F51B5', textAlign:'center',flex:1, fontSize: 17,justifyContent: 'center',alignItems:  'center'  }}> {parseFloat((cartNow[products].SizePrices[key] * cartNow[products].SelectedSizesArray[qts].Qty) +(cartNow[products].SizePrices[key] * cartNow[products].SelectedSizesArray[qts].Qty * cartNow[products].SGST/100)+(cartNow[products].SizePrices[key] * cartNow[products].SelectedSizesArray[qts].Qty * cartNow[products].CGST/100)).toFixed(2)}/-</h2>
	            			 	
	            	</div>		 	
                    
            )
          }  
        }
  			
  		}
  		return(RenderingArr)
  	}
  

	render(){
		var self = this;
		return(
			<div style={{position: 'relative',top:17,height: '77vh' }}>
				<Modal modalStyle={{padding:0,width:'60%',height:'90%',overflowY: 'visible' }} showCloseIcon={true} closeIconSize={24}  onClose={()=>{this._closeOtherModal.bind(this)()}} open={this.state.ShowOtherModal} >
					<div style={{ backgroundColor: '#ffffff', flex: 1,elevation: 5,justifyContent:  'space-between'  }}>
            			  <div style={{flexDirection: 'row',justifyContent: 'space-around',alignItems:  'center',elevation: 4,backgroundColor:'#FFC107',position: 'relative',top:-30  }}>
            		  		  <h4 style={{fontSize: 22,fontStyle:'italic',color: '#3F51B5',  paddingTop: 7,paddingBottom: 7}}>Another Special Item!</h4>
            			  </div>
            			 <div style={{flex:1}}>
            			  	<div style={{position: 'relative',top:-30 }}>
            			  		<h3 style={{fontSize: 14,fontStyle:'italic',color: '#3F51B5',  paddingTop: 0,paddingBottom: 0}}>This an option To Add Redundant Special Item(s) to cart, Item(s) Added Using this menu, can't be removed from Cart. In Order to remove them, go back to main menu and re-create the bill.</h3>
            			  	 	<Button label='Select..' labelColor='#FFC107' labelStyle={{fontSize:20}} backgroundColor='#3F51B5' style={{alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:35,width: '96%',marginLeft: '2%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}}   onClick={()=>{self.setState({RandomSelectorShow:true})}}>
								</Button>	
						  	</div>  
						  	<If test={this.state.modalDatax.length!=0}>
						  	   <div>
						  		 <div style={{justifyContent: 'space-around'  }}>
                       				 <h5 style={{marginBottom: 10, color: '#3F51B5',textAlign:'justify' , flex:1, fontSize: 18,justifyContent: 'center',alignItems:  'center'  }}>{this.state.modalDatax.ItemCategory} is a Special Item with CGST: {this.state.modalDatax.CGST}% and SGST: {this.state.modalDatax.SGST}%. Please Specify Tax exclusive Price Below in order to continue... </h5>
                              	 </div>
                                 <div>
                                 	<TextField value={self.state.SpecialQTYPrice+''} onChange={(spPrices)=>{self.setState({SpecialQTYPrice:spPrices.target.value});}} style={{flex:1,width:'48%'}} disabled={false}  floatingLabelText="Enter Price" />&nbsp;&nbsp;
                  					<Button label={'QTY :'+this.state.SpecialQTY} labelColor='#FFC107' labelStyle={{fontSize:20}} backgroundColor='#3F51B5' style={{alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:35,width: '96%',marginLeft: '2%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}}   onClick={()=>{self.setState({QtySelModal:true,ChangingFunc:this.specialQtyChangeHandler.bind(this)})}}>
									</Button>
	                          	</div>
	                          </div>	
      						</If>
      						<Button label='Add To Bill' labelColor='#FFC107' labelStyle={{fontSize:20}} backgroundColor='#3F51B5' style={{position: 'absolute',bottom: 0,alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:35,width: '96%',marginLeft: '2%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}}   onClick={()=>{this.AddToCartClicked.bind(this,this.state.modalDatax.checked)()}}>
							</Button>
      					</div>	
				    </div>
            	</Modal>
            	<Modal modalStyle={{padding:0,width:'60%',minHeight:'90%',maxHeight:'700%',overflowY: 'visible'  }} showCloseIcon={true} closeIconSize={24}   onClose={()=>{this._hideCartModal.bind(this)()}} open={this.state.cartModalVisible}>
        			  	<div style={{display:'flex',flexDirection: 'column', backgroundColor: '#ffffff', flex: 1,elevation: 5,justifyContent:  'space-between',height: '100%',overflowY:'scroll'   }}>
            			  <div  style={{zIndex:50000, height:44,justifyContent: 'space-around',alignItems:  'center',elevation: 4,backgroundColor:'#FFC107',position: 'absolute',top:0,width:'100%' }} className={'shadow'}>
            		  		  <center>
            		  		  		<h4 style={{fontSize: 22,fontStyle:'italic',color: '#3F51B5',position:'relative',top:7,  paddingTop: 0,paddingBottom: 0,margin:0}}>Bill Memo</h4>
            			  	  </center>	
            			  </div>
            			 </div>
            	</Modal>
            	<Modal modalStyle={{padding:0,width:'60%',height:'90%',overflowY: 'visible' }} showCloseIcon={true} closeIconSize={24}  onClose={()=>{this._hideCartModal.bind(this)()}} open={this.state.cartModalVisible}>
        				<div style={{ backgroundColor: '#ffffff', flex: 1,elevation: 5,justifyContent:  'space-between'  }}>
            			  <div style={{flexDirection: 'row',justifyContent: 'space-around',alignItems:  'center',elevation: 4,backgroundColor:'#3F51B5',position: 'relative',top:-30  }}>
            		  		  <h4 style={{fontSize: 22,fontStyle:'italic',color: '#FFC107',  paddingTop: 7,paddingBottom: 7}}>Bill Memo</h4>
            			  </div>
            			  <div style={{display:'flex',flexDirection:'column', width:'100%',borderWidth: 5, position:'relative', top:50}}>
	            			 	<div style={{width:'100%',display:'flex',flexDirection: 'row',justifyContent: 'space-around' ,alignItems: 'center'  }}>
	            			 		<h2 style={{color: '#3F51B5',textAlign:'center', flex:1, fontSize: 23,justifyContent: 'center',alignItems:  'center'  }}>Item</h2>
	            			 		<h2 style={{color: '#3F51B5',textAlign:'center',flex:1, fontSize: 23,justifyContent: 'center',alignItems:  'center'  }}>Qty</h2>
	            			 		<h2 style={{color: '#3F51B5', textAlign:'center',flex:1, fontSize: 23,justifyContent: 'center',alignItems:  'center'  }}>Rate</h2>
	            			 		<h2 style={{color: '#3F51B5', textAlign:'center',flex:1, fontSize: 23,justifyContent: 'center',alignItems:  'center'  }}>Amt</h2>
	            			 	</div>
	            			 	 
	            				 {
									self.renderMemo.bind(self)()
	            				 }
	            			 	 
	            		   </div>
            			            			 
        				{/*
            			  	<View style={{flex:1}}>
	            			 	 
	            			 	<ScrollView>
	            			 	{
	            			 		this.renderMemo.bind(this)()
	            			 	}
	            			 	</ScrollView>
	            			 </View>	
	            			 <Button onPress={()=>{this.setState({billSettingModal:true,cartModalVisible:false})}} containerViewStyle={{elevation:5,padding:0,margin: 0,width:'100%',position: 'absolute',bottom: 0,left:'-4.6%',flex:1}} large color='#FFC107' buttonStyle={{width: '100%'}} backgroundColor='#3F51B5'  title='Print Bill' />	
        				*/}
			 		</div>
        		 </Modal>
        		 <Modal modalStyle={{padding:0,width:'60%',minHeight:'90%',maxHeight:'700%',overflowY: 'visible'  }} showCloseIcon={true} closeIconSize={24}   onClose={()=>{this._hideModal.bind(this)()}} open={this.state.modalVisible}>
        			  	<div style={{display:'flex',flexDirection: 'column', backgroundColor: '#ffffff', flex: 1,elevation: 5,justifyContent:  'space-between',height: '100%',overflowY:'scroll'   }}>
            			  <div  style={{zIndex:50000, height:44,justifyContent: 'space-around',alignItems:  'center',elevation: 4,backgroundColor:'#FFC107',position: 'absolute',top:0,width:'100%' }} className={'shadow'}>
            		  		  <center>
            		  		  		<h4 style={{fontSize: 22,fontStyle:'italic',color: '#3F51B5',position:'relative',top:7,  paddingTop: 0,paddingBottom: 0,margin:0}}>{this.state.modalData.ItemCategory}!</h4>
            			  	  </center>	
            			  </div>
            			  <If test={this.state.modalData.checked}>
	            			 {/*It's a Special Item*/}
                     		<div style={{height: '100%', justifyContent: 'space-around',position: 'relative',top:35   }}>
                       			 <h2 style={{marginBottom: 0, color: '#3F51B5',textAlign:'justify' , flex:1, fontSize: 18,justifyContent: 'center',alignItems:  'center'  }}>{this.state.modalData.ItemCategory} is a Special Item with CGST: {this.state.modalData.CGST}% and SGST: {this.state.modalData.SGST}%. Please Specify Tax exclusive Price Below in order to continue... </h2>
                                 <TextField value={self.state.SpecialQTYPrice+''} onChange={(spPrices)=>{self.setState({SpecialQTYPrice:spPrices.target.value});}} style={{flex:1,width:'88%'}} disabled={false}   hintText='Enter Price' type={'numeric'}  floatingLabelText="Enter Price" />&nbsp;&nbsp;
                  				 <Button label={'QTY :'+this.state.SpecialQTY} labelColor='#FFC107' labelStyle={{fontSize:20}} backgroundColor={'#3F51B5'} style={{alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:55,width: '96%',marginLeft: '2%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}} onClick={()=>{self.setState({QtySelModal:true,ChangingFunc:self.specialQtyChangeHandler.bind(self)})}}></Button>
                                  
                            </div>
                  		  </If>
	            		  <If test={!this.state.modalData.checked}>
	            			 {/*Not a Special Item*/}
	            			<div style={{display:'flex',flexDirection:'column', width:'100%',borderWidth: 5, position:'relative', top:50}}>
	            			 	<div style={{width:'100%',display:'flex',flexDirection: 'row',justifyContent: 'space-around' ,alignItems: 'center'  }}>
	            			 		<h2 style={{color: '#3F51B5',textAlign:'center', flex:1, fontSize: 23,justifyContent: 'center',alignItems:  'center'  }}>Sizes</h2>
	            			 		<h2 style={{color: '#3F51B5',textAlign:'center',flex:1, fontSize: 23,justifyContent: 'center',alignItems:  'center'  }}>Price</h2>
	            			 		<h2 style={{color: '#3F51B5', textAlign:'center',flex:1, fontSize: 23,justifyContent: 'center',alignItems:  'center'  }}>Qty</h2>
	            			 	</div>
	            			 	 
	            				 {
									self.renderNotSpecial.bind(self)()
	            				 }
	            			 	 
	            			 </div>
	            		  </If>
	            		  <Button label={'Add To Bill'} labelColor='#FFC107' labelStyle={{fontSize:20}} backgroundColor={'#3F51B5'} style={{alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:35,width: '94%',marginLeft: '0.5%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%',position: 'absolute',bottom: 0}} onClick={()=>{self.AddToCartClicked.bind(self,self.state.modalData.checked)()}}></Button>
                                 
         			 </div>
         		
         			 
					<br/><br/><br/><br/><br/><br/><br/><br/>

        		  </Modal>

				<div style={{position:'relative', top:20}} >
					<div style={{ flexDirection: 'row', flexWrap: 'wrap', flex: 1}}>
					<Button label='Another' labelColor='#FFC107' labelStyle={{fontSize:20}} backgroundColor='#3F51B5' style={{alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:100,width: '24%',marginLeft: '0.5%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}}  onClick={()=>this._showOtherModal.bind(this)()}>
						
					</Button>
					{
						
						this.state.data.map((item)=>{
							if(item.SizePrices || item.checked){
								return(
									<Button key={item.ItemCategory+'toucha'} label={item.ItemCategory} labelColor='#FFC107' labelStyle={{fontSize:20}} backgroundColor='#3F51B5' style={{alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:100,width: '24%',marginLeft: '0.5%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}}  onClick={()=>this._showModal.bind(this,item)()}>
									</Button> 
 								)
							}
							else{
							}
							
						})
					}
					

					<br/><br/><br/><br/><br/><br/><br/><br/><br/><br/><br/>

					</div>
				</div>
				<RandomSelector allData={this.state.data} showRandom={this.state.RandomSelectorShow} RandomChangeHandleFunc={this.RandomSelectorHandler.bind(this)} />    
				<QtySelector ChangeHandlerFunc={this.state.ChangingFunc.bind(this)} hideQtySelector={this.hideQtySelector.bind(this)} visibility={this.state.QtySelModal} />
				<Button label={`You have ${this.state.cart.length} product(s) and ${this.renderTotalItems.bind(this)()} item(s) in Cart`} labelColor='#3F51B5' labelStyle={{fontSize:20}} backgroundColor='#FFC107' style={{position: 'fixed',bottom: 55,alignSelf: 'center', justifyContent:  'space-around', alignItems: 'center', elevation: 4, height:55,width: '96%',marginLeft: '2%',marginBottom: 5,paddingBottom: 5,marginRight: '0.5%'}}   onClick={()=>{this._showCartModal.bind(this)()}}>
				</Button>
				

			</div>
		)
	}
} 
export default BillMain;