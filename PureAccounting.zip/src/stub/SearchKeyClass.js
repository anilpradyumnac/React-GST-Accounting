class SearchKeyClass {
  constructor() {
    this.SearchData = '';
    
  }
}
export default (new SearchKeyClass);