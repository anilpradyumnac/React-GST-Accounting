import React from 'react';
import { Link, withRouter } from 'react-router';
import { default as Header } from '../../header/components';

import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';

export default withRouter(React.createClass({

  componentWillMount(){
   if(!this.props.children){
      this.props.router.replace('/Home');
   } 
  },
  render(){
    var self=this;
    if(this.props.children){

      var children = React.Children.map(this.props.children, function (child) {
        return React.cloneElement(child)
      })
      return (
        <MuiThemeProvider>
        <div className="App">
          <Header />
          <br/> 
          <section>
            {children}
          </section>
        </div> 
        </MuiThemeProvider>
      ) 
    }else{
      return <div>Hotex Uniforms</div>
    }
    
  }
 
}));
