import { default as If } from './If';
export {
	If
};