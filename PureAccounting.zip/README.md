# README #

Follow the following instruction if facing any problem in bootstrapping the application

### How do I get set up? ###

* Clone the repository
* now move inside the forlder tripshire-react
* use the command ```npm install```. If npm does not exist download it from [Install Node](https://nodejs.org/en/download/) 
* Run the command ```npm start 2000``` to start server
* Use localhost:3000 in your browser